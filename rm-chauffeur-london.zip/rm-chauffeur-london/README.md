# RM Chauffeur London

Marketing and booking website for RM Chauffeur London — a premium chauffeur
service operating across London and the United Kingdom.

**Driven by excellence. Defined by trust.**

## Pages

- **Home** — hero banner, services overview, fleet preview, values and booking call-to-action
- **Services** — airport transfers (all six London airports), weddings, special occasions and private hire
- **Fleet** — Mercedes-Benz S-Class, V-Class and the Mercedes party bus
- **About** — the brand story and values
- **Booking** — full booking form with journey details, vehicle choice and instant reference number
- **Contact** — contact channels and frequently asked questions
- Privacy policy, terms of service, custom 404, sitemap, robots and Open Graph image

## Tech stack

- [Next.js](https://nextjs.org) (App Router) + TypeScript
- [Tailwind CSS v4](https://tailwindcss.com) with the brand palette (`#0A0A0A` / `#1A1A1A` / `#D4AF37` / `#F2D97D` / `#FFFFFF`)
- [shadcn/ui](https://ui.shadcn.com) components
- [Zod](https://zod.dev) validation on the booking API route

## Getting started

```bash
npm install
npm run dev
```

The site runs at http://localhost:3000 by default (`npm run dev -- -p <port>` to change).

## Booking requests

The booking form posts to `POST /api/booking`. Without configuration, accepted
bookings are written to the server log so the site works out of the box. To
forward bookings to email, Slack or an automation platform, set:

```bash
BOOKING_WEBHOOK_URL=https://your-webhook-endpoint
```

Each request is validated and given a reference like `RM-260829-XXXX`.

## Things to update before going live

- `src/lib/site.ts` — replace the placeholder telephone number (`+44 7XXX XXXXXX`)
  and confirm the public URL and email address.
- Photography — the images in `public/images/` are AI-generated placeholders
  styled after the brand moodboard. Swap in real photography of the fleet when
  available (keep the same filenames and no code changes are needed).
